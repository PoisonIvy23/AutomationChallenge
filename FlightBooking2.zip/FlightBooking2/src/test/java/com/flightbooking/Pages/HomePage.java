package com.flightbooking.Pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.flightbooking.runner.TestRunner;
import com.flightbooking.utility.Log;

public class HomePage extends TestRunner {
	static WebDriverWait wait=new WebDriverWait(driver, 60);;
	static List<WebElement> fares;
	static List<WebElement> allDuration;
	static ArrayList<Integer> durationInSeconds;
	@FindBy(xpath="//a[@class='ctBrand']/span[@title='Cleartrip ']")
	private static WebElement title;
	
	@FindBy(id="FromTag")
	private static WebElement departFrom;
	
	@FindBy(id="ToTag")
	private static WebElement goingTo;
	
	@FindBy(id="DepartDate")
	private static WebElement departDate;
	@FindBy(id="SearchBtn")
	private static WebElement searchFlights;
	
	@FindBy(xpath="//div[@class='col-5']/div/aside/div[4]/div[3]/div[2]/div[1]/label[4]/div[1]/span")
	private static WebElement eveningCheckbox;
	public static void launchurl()
	{
		String expectedUrl="https://www.cleartrip.com/";
		driver.get(expectedUrl);
		driver.manage().window().maximize();
		String actualUrl=driver.getCurrentUrl();
		Assert.assertEquals(expectedUrl, actualUrl);
		
	}
	
	public static void enterSource(String source)
	{
		wait.until(ExpectedConditions.visibilityOf(departFrom));
		departFrom.clear();
		departFrom.sendKeys(source);
	}

	public static void enterDestination(String destination)
	{
		wait.until(ExpectedConditions.visibilityOf(goingTo));
		goingTo.clear();
		goingTo.sendKeys(destination);
	}
	public static void enterDate()
	{
		wait.until(ExpectedConditions.visibilityOf(departDate));
		departDate.clear();
		departDate.sendKeys("Sat, 15 Aug, 2020");
		departDate.sendKeys(Keys.ENTER);
	}
	
	public static void searchFlights() throws InterruptedException
	{
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView(true);", searchFlights);
		searchFlights.click();
		Thread.sleep(10000);
	}
	public static ArrayList<Integer> getFares() throws InterruptedException
	{
		Thread.sleep(5000);
		
		ArrayList<Integer> pricesList=new ArrayList<Integer>();
		fares=driver.findElements(By.xpath("//th[@id='BaggageBundlingTemplate']"));
		
		if(fares.isEmpty()||fares==null)
		{
			Thread.sleep(10000);
		fares=driver.findElements(By.xpath("//div[@data-ct-handle='solutionPrice']/p"));
		}
		for(int i=0;i<fares.size();i++)
		{
			int fare=Integer.parseInt(fares.get(i).getText().replaceAll("[^0-9]", ""));
			pricesList.add(fare);
		}
		for(int flightfares:pricesList)
		{
		Log.info("flightfares"+flightfares);
		}
		return pricesList;
	}

	
	
	public static void getFastestAndCheapestItinerary() throws InterruptedException	{
		Thread.sleep(3000);
		List<WebElement> allBookbtn;
		ArrayList<Integer> alltimes=getDuration();
		int minTime=Collections.min(alltimes);
		ArrayList<Integer> allPrices=getFares();
		int minPrice=Collections.min(allPrices);
		allBookbtn = driver.findElements(By.xpath("//div[@class='flex flex-right nmt-1 ms-grid-column-4']/button"));
		if(allBookbtn.isEmpty()||allBookbtn==null)
		{
			allBookbtn=driver.findElements(By.xpath("//td[@class='price   actionPrice   ']/button"));
		}
		Thread.sleep(3000);
		for(int k=0;k<durationInSeconds.size();k++){
			if(durationInSeconds.get(k)==minTime){
				for(int i=0;i<fares.size();i++){
					Integer priceInt1 = Integer.valueOf(fares.get(i).getText().replaceAll("[^0-9]", ""));
					Log.info("Price in Integer format"+priceInt1);
					if(priceInt1==minPrice){
					allBookbtn.get(i).click();
					break;
		}
		
	}
}
		}
		Thread.sleep(6000);
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL+"\t");
		Thread.sleep(6000);
	}
	public static ArrayList<Integer> getDuration() throws InterruptedException
	{
		String[] lst;
		Thread.sleep(5000);
		allDuration = driver.findElements(By.xpath("//div[@class='ms-grid-column-3 ms-grid-row-1']/p"));
		if(allDuration.isEmpty()||allDuration==null)
		{
			allDuration=driver.findElements(By.xpath("//th[@class='duration']"));
		}
	durationInSeconds=new ArrayList<Integer>();
	for(int j=0;j<allDuration.size();j++)
	{
		String duration=allDuration.get(j).getText();
		if(duration.contains("h")){
		lst=duration.split("\\s+");
		Log.info(lst[0]);
		Log.info(lst[1]);
		int hours=Integer.parseInt(lst[0].replaceAll("[^0-9]", ""));
		int minutes=Integer.parseInt(lst[1].replaceAll("[^0-9]", ""));
		int seconds=(hours*60*60)+(minutes*60);
		durationInSeconds.add(seconds);
		}
		else
		{
			int minutes=Integer.parseInt(duration.replaceAll("[^0-9]", ""));
			int seconds=minutes*60;
			durationInSeconds.add(seconds);
		}
	}
	for(int timeDuration:durationInSeconds)
	{
	Log.info("Time duration in seconds"+timeDuration);
	}
	return durationInSeconds;
	}
}
