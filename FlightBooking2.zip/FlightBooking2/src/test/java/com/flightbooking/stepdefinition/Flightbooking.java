package com.flightbooking.stepdefinition;

import com.flightbooking.Pages.HomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Flightbooking {

	@Given("^I open cleartrip website$")
	public void i_open_cleartrip_website() throws Throwable {
		HomePage.launchurl();

	}

	@When("^I Search for \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_Search_for_source_and_destination(String source, String destination) throws Throwable {
		HomePage.enterSource(source);
		HomePage.enterDestination(destination);
		HomePage.enterDate();
		HomePage.searchFlights();
	}

	
	@Then("^Select fastest and cheapest travel itinerary$")
	public void getbestTravel() throws InterruptedException {
		HomePage.getFastestAndCheapestItinerary();
	}

	
}
