package com.flightbooking.runner;

import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.flightbooking.Pages.HomePage;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions(features = "src/test/java/com/flightbooking/feature",glue={"com.flightbooking.stepdefinition"},plugin = {"html:target/cucumber-html-report","json:target/cucumber.json","pretty:target/cucumber-pretty.txt","junit:target/cucumber-results.xml" })
//public class TestRunner extends AbstractTestNGCucumberTests{
public class TestRunner{
	 public static WebDriver driver;
	private TestNGCucumberRunner testNGCucumberRunner;
	 
    @BeforeClass(alwaysRun = true)
    public void setUpClass() throws Exception {
    	testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());  
    }
 
    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
    public void feature(CucumberFeatureWrapper cucumberFeature) {
        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
    }
    
    @DataProvider
    public Object[][] features(){
    	return testNGCucumberRunner.provideFeatures();
    }
    @AfterClass(alwaysRun = true)
    public void tearDownCLass()
    {
    	testNGCucumberRunner.finish();
    }
	
   
	@BeforeClass
		@Parameters("browser")
		public WebDriver launchChromeBrowser(String browser) {
		DOMConfigurator.configure("src/test/java/com/flightbooking/utility/log4j.xml");
			if (browser.equals("chrome")) {
				ChromeOptions options=new ChromeOptions();
				options.addArguments("--disable-notifications");
				System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");
				driver = new ChromeDriver(options);
			}
			if (browser.equals("safari")) {
				driver = new SafariDriver();
			}
			PageFactory.initElements(TestRunner.driver, HomePage.class);
			return driver;
		}

	@AfterClass(alwaysRun = true)
    public void closeBrowser()
    {
    	driver.close();
    }
}

